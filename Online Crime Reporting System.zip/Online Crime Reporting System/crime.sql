-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2019 at 09:41 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crime`
--

-- --------------------------------------------------------

--
-- Table structure for table `accused_details`
--

CREATE TABLE `accused_details` (
  `a_id` int(11) NOT NULL,
  `u_id` int(4) NOT NULL,
  `a_name` varchar(20) NOT NULL,
  `a_address` varchar(40) NOT NULL,
  `a_gender` varchar(10) NOT NULL,
  `otherinfo` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accused_details`
--

INSERT INTO `accused_details` (`a_id`, `u_id`, `a_name`, `a_address`, `a_gender`, `otherinfo`) VALUES
(6, 1, 'unknown', 'unknown', 'male', 'A tall man around 6 feet tall with muscu');

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `user` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`user`, `password`) VALUES
('admin@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `incident_details`
--

CREATE TABLE `incident_details` (
  `inc_id` int(11) NOT NULL,
  `u_id` int(4) NOT NULL,
  `noc` varchar(20) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `district` varchar(20) NOT NULL,
  `pstation` varchar(20) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `city` varchar(25) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `inc_desc` varchar(50) NOT NULL,
  `incpic` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incident_details`
--

INSERT INTO `incident_details` (`inc_id`, `u_id`, `noc`, `date`, `time`, `state`, `district`, `pstation`, `pincode`, `city`, `phone`, `inc_desc`, `incpic`) VALUES
(6, 1, 'Robbery', '`15/01/2019', '1:20 AM', 'Kerala', 'Thrissur', 'Viyoor', '680581', 'Thrissur', '9889665690', 'The incident occurred around midnight at 1:20 pm.T', 'img/robbery.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `status_details`
--

CREATE TABLE `status_details` (
  `s_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `victim_id` int(11) NOT NULL,
  `a_id` int(11) NOT NULL,
  `inc_id` int(11) NOT NULL,
  `message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_details`
--

INSERT INTO `status_details` (`s_id`, `u_id`, `victim_id`, `a_id`, `inc_id`, `message`) VALUES
(5, 1, 9, 6, 6, 'Your complaint has been forwarded.Please wait for ');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `u_id` int(4) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `lastname` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`u_id`, `firstname`, `lastname`, `gender`, `dob`, `address`, `phone`, `email`, `password`) VALUES
(1, 'athul', 's kumar', 'Male', '23/03/1998', 'sddasdasd', 1231232132, 'athul@gmail.com', '123456'),
(2, 'akshay', 'kr', 'Male', '08/12/1998', 'asdasdasd', 2132455646, 'akshaykr@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `victim_details`
--

CREATE TABLE `victim_details` (
  `victim_id` int(4) NOT NULL,
  `u_id` int(4) NOT NULL,
  `name` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `idtype` varchar(20) NOT NULL,
  `idno` varchar(20) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `address` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `victim_details`
--

INSERT INTO `victim_details` (`victim_id`, `u_id`, `name`, `fname`, `mname`, `email`, `gender`, `dob`, `idtype`, `idno`, `phoneno`, `nationality`, `address`) VALUES
(9, 1, 'Athul', 'Suresh Kumar', 'Sajitha', 'athul@gmail.com', 'male', '23/03/1998', 'aadhar', '123123354576788', '9876543123', 'Indian', 'Sarangi House P O Pottore via MG Kavu, Thriss');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accused_details`
--
ALTER TABLE `accused_details`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`user`),
  ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `incident_details`
--
ALTER TABLE `incident_details`
  ADD PRIMARY KEY (`inc_id`);

--
-- Indexes for table `status_details`
--
ALTER TABLE `status_details`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `victim_details`
--
ALTER TABLE `victim_details`
  ADD PRIMARY KEY (`victim_id`),
  ADD UNIQUE KEY `idno` (`idno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accused_details`
--
ALTER TABLE `accused_details`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `incident_details`
--
ALTER TABLE `incident_details`
  MODIFY `inc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `status_details`
--
ALTER TABLE `status_details`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `u_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `victim_details`
--
ALTER TABLE `victim_details`
  MODIFY `victim_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
