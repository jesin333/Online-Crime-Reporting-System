<?php
session_start();
if(isset($_SESSION['u_id'])&&isset($_SESSION['fname']))
{
}
else
header('location:login.php');
?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="favicon.png" type="image/png">
	<link rel="shortcut icon" href="favicon.ico" type="img/x-icon">

	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,800italic,700italic,600italic,400italic,300italic,800,700,600' rel='stylesheet' type='text/css'>

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>
	<script type="text/javascript" src="js/wow.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/magnific-popup.js"></script>
	<script src="contactform/contactform.js"></script>

	<!-- =======================================================
    Theme Name: Knight
    Theme URL: https://bootstrapmade.com/knight-free-bootstrap-theme/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
	======================================================= -->

</head>

<body>

	<!--header-end-->
<?php include'usermenu.php';?>
	<!--main-nav-end--><!--main-section-end-->

<section class="business-talking">
		<!--business-talking-start-->
		<div class="container">
			<h2>My Complaint</h2>
		</div>
</section>
	<!--business-talking-end-->
<div class="container">
<section class="main-section contact" id="contact">
<div class="row">
<div class="col-lg-4">
<?php
include'connect.php';
$u=$_SESSION['u_id'];
$res=mysql_query("select * from victim_details where u_id='$u'");
$count=mysql_num_rows($res);
if($count<=0)
{
	
	die( "<h1>No complaint filed</h1>");
}

else
{
echo "<table float:left>";
while($row=mysql_fetch_array($res))
{
				$vid=$row[0];
				$uid=$row[1];
				$n=$row[2];
				$fn=$row[3];
				$mn=$row[4];
				$e=$row[5];
				$g=$row[6];
				$dob=$row[7];
				$idt=$row[8];
				$idn=$row[9];
				$ph=$row[10];
			    $na=$row[11];
			    $ad=$row[12];
				
				echo "<caption><h3>Victim Details<h3></caption>
				<tr>
				<td align='left'><b>Victim ID</b></td>
				<td align='center'>$vid</td></tr>
				<tr><td align='left'><b>User ID</b></td>
				<td align='center'>$uid</td></tr>
				<tr><td align='left'><b>Name of Victim</b></td>
				<td align='center'>$n</td></tr>
				<tr><td align='left'><b>Name of Victim's father</b></td>
				<td align='center'>$fn</td></tr>
				<tr><td align='left'><b>Name of Victim's mother</b></td>
				<td align='center'>$mn</td></tr>
				<tr><td align='left'><b>Email</b></td>
				<td align='center'>$e</td></tr>
				<tr><td align='left'><b>Gender<b>/td>
				<td align='center'>$g</td></tr>
				<tr><td align='left'><b>Date of birth</b></td>
				<td align='center'>$dob</td></tr>
				<tr><td align='left'><b>ID Type</b></td>
				<td align='center'>$idt</td></tr>
				<tr><td align='left'><b>ID No.</b></td>
				<td align='center'>$idn</td></tr>
				<tr><td align='left'><b>Phone</b></td>
				<td align='center'>$ph</td></tr>
				<tr><td align='left'><b>Nationality</b></td>
				<td align='center'>$na</td></tr>
				<tr><td align='left'><b>Address</b></td>
				<td align='center'>$ad</td></tr>";
				
}
echo "</table>";

}

mysql_close();
?>
</div>
<div class="col-lg-4">

<?php
include'connect.php';
$u=$_SESSION['u_id'];
$res1=mysql_query("select * from accused_details where u_id='$u'");
$count=mysql_num_rows($res1);
if($count<=0)
{
	
	die( "<h1>No complaint filed</h1>");
}

else
{
echo "<table float:left>";
while($row=mysql_fetch_array($res1))
{
				$aid=$row[0];
				$uid=$row[1];
				$an=$row[2];
				$aad=$row[3];
				$ag=$row[4];
				$oi=$row[5];
				
				
    echo "<caption><h3>Accused Details<h3></caption>
				<tr>
				<td align='left'><b>Accused ID</b></td>
				<td align='center'>$aid</td></tr>
				<tr><td align='left'><b>User ID</b></td>
				<td align='center'>$uid</td></tr>
				<tr><td align='left'><b>Name of Accused</b></td>
				<td align='center'>$an</td></tr>
				<tr><td align='left'><b>Addressr</b></td>
				<td align='center'>$aad</td></tr>
				<tr><td align='left'><b>Gender</b></td>
				<td align='center'>$ag</td></tr>
				<tr><td align='left'><b>Other Info</b></td>
				<td align='center'>$oi</td></tr>";
				
}
echo "</table>";

}

?>
</div>
<div class="col-lg-4">

<?php
include'connect.php';
$u=$_SESSION['u_id'];
$res2=mysql_query("select * from incident_details where u_id='$u'");
$count=mysql_num_rows($res2);
if($count<=0)
{
	
	die( "<h1>No complaint filed</h1>");
}

else
{
echo "<table float:left>";
while($row=mysql_fetch_array($res2))
{
				$iid=$row[0];
				$uid=$row[1];
				$noc=$row[2];
				$date=$row[3];
				$ti=$row[4];
				$st=$row[5];
				$di=$row[6];
				$ps=$row[7];
				$pi=$row[8];
				$ci=$row[9];
				$ph=$row[10];
				$ind=$row[11];
				$inp=$row[12];
				
				
				echo "<caption><h3>Incident Details<h3></caption>
				<tr>
				<td align='left'><b>Incident ID</b></td>
				<td align='center'>$iid</td></tr>
				<tr><td align='left'><b>User ID</b></td>
				<td align='center'>$uid</td></tr>
				<tr><td align='left'><b>Nature of Complaint</b></td>
				<td align='center'>$noc</td></tr>
				<tr><td align='left'><b>Date</b></td>
				<td align='center'>$date</td></tr>
				<tr><td align='left'><b>Stater</b></td>
				<td align='center'>$st</td></tr>
				<tr><td align='left'><b>District</b></td>
				<td align='center'>$di</td></tr>
				<tr><td align='left'><b>Police Station</b></td>
				<td align='center'>$ps</td></tr>
				<tr><td align='left'><b>Pincode</b></td>
				<td align='center'>$pi</td></tr>
				<tr><td align='left'><b>City</b></td>
				<td align='center'>$ci</td></tr>
				<tr><td align='left'><b>Phone</b></td>
				<td align='center'>$ph</td></tr>
				<tr><td align='left'><b>Incident Description</b></td>
				<td align='center'>$ind</td></tr>
				<tr><td align='left'><b>Incident Picture</b></td>
				<td align='center'>";?>
                <img src="<?php echo $inp;?>">
                <?php echo"</td></tr>
				";
				
}
echo "</table>";

}

mysql_close();
?>

</div>
</div>
</section>
</div>

	<!--main-section alabaster-end--><!--main-section-end--><!--main-section client-part-end--><!--c-logo-part-end-->
	<section class="main-section team" id="team">
 
	<!--main-section team-start--></section>
	<!--main-section team-end-->



		<footer class="footer">
		<div class="container">
			<div class="footer-logo"><a href="#"><img src="img/footer-logo.png" alt=""></a></div>
			<span class="copyright">&copy; Knight Theme. All Rights Reserved</span>
			<div class="credits">
				<!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Knight
        -->
				Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
			</div>
		</div>
	</footer>


	<script type="text/javascript">
		$(document).ready(function(e) {

			$('#test').scrollToFixed();
			$('.res-nav_click').click(function() {
				$('.main-nav').slideToggle();
				return false

			});

      $('.Portfolio-box').magnificPopup({
        delegate: 'a',
        type: 'image'
      });

		});
	</script>

	<script>
		wow = new WOW({
			animateClass: 'animated',
			offset: 100
		});
		wow.init();
	</script>


	<script type="text/javascript">
		$(window).load(function() {

			$('.main-nav li a, .servicelink').bind('click', function(event) {
				var $anchor = $(this);

				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top - 102
				}, 1500, 'easeInOutExpo');
				/*
				if you don't want to use the easing effects:
				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top
				}, 1000);
				*/
				if ($(window).width() < 768) {
					$('.main-nav').hide();
				}
				event.preventDefault();
			});
		})
	</script>

<script type="text/javascript">
		$(window).load(function() {


			var $container = $('.portfolioContainer'),
				$body = $('body'),
				colW = 375,
				columns = null;


			$container.isotope({
				// disable window resizing
				resizable: true,
				masonry: {
					columnWidth: colW
				}
			});

			$(window).smartresize(function() {
				// check if columns has changed
				var currentColumns = Math.floor(($body.width() - 30) / colW);
				if (currentColumns !== columns) {
					// set new column count
					columns = currentColumns;
					// apply width to container manually, then trigger relayout
					$container.width(columns * colW)
						.isotope('reLayout');
				}

			}).smartresize(); // trigger resize to set container width
			$('.portfolioFilter a').click(function() {
				$('.portfolioFilter .current').removeClass('current');
				$(this).addClass('current');

				var selector = $(this).attr('data-filter');
				$container.isotope({

					filter: selector,
				});
				return false;
			});

		});
	</script>

</body>

</html>
