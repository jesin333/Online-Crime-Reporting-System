<?php
$con=mysql_connect("localhost",'root');
if($con==false)
die("Cannot establish a connection");
$flag=mysql_select_db("crime");
if($flag==false)
die("database is not inserted");
if(isset($_POST['btnreg']))
{
	$f=$_POST["fname"];
	$l=$_POST["lname"];
	$g=$_POST["optradio"];
	$dob=$_POST["dob"];
	$a=$_POST["address"];
	$ph=$_POST["phone"];
	$e=$_POST["email"];
	$p=$_POST["password"];
	$cp=$_POST["confirm"];
	if($p==$cp)
	{
		$res=mysql_query("INSERT INTO `user_details` VALUES ('','$f','$l','$g','$dob','$a','$ph','$e','$p')");
		if($res)
		{
	  		echo "Registration Successful and you will be redirected within 3 seconds";
	  		header('refresh:3;url=login.php');
		}
		else
		{
			echo "Registration Failed and you will be redirected within 3 seconds";
	  		header('refresh:3;url=index.php');
		}
	
	}
	else
	echo "Password Mismatch";	
}
mysql_close();

?>