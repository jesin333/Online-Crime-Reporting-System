<?php
session_start();

$con=mysql_connect("localhost",'root');
if($con==false)
die("Cannot establish a connection");
$flag=mysql_select_db("crime");
if($flag==false)
die("database is not inserted");

if(isset($_POST['btnlogin']))
{
	$e=$_POST["email"];
	$p=$_POST["password"];
    $res=mysql_query("select * from user_details where email='$e' and password='$p'");
	$count=mysql_num_rows($res);
	if($count>0)
	{
		while($obj=mysql_fetch_array($res))
		{
			$_SESSION['u_id']=$obj[0];
			$_SESSION['fname']=$obj[1];
		}
	  	  header('location:userhome.php');

	}
	else
	echo "Incorrect email or password";	

}
mysql_close();

?>