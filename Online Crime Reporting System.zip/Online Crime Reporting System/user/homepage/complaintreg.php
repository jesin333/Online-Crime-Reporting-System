<?php
session_start();
if(isset($_SESSION['u_id'])&&isset($_SESSION['fname']))
{
}
else
header('location:login.php');
$con=mysql_connect("localhost",'root');
if($con==false)
die("Cannot establish a connection");
$flag=mysql_select_db("crime");
if($flag==false)
die("database is not inserted");

if(isset($_POST['btnsave']))
{
	$u=$_SESSION['u_id'];
	$n=$_POST["name"];
	$fn=$_POST["fname"];
	$mn=$_POST["mname"];
	$e=$_POST["email"];
	$g=$_POST["gender"];
	$d=$_POST["dob"];
	$p=$_POST["phone1"];
	$idc=$_POST["idtype"];
	$cn=$_POST["cardno"];
	$na=$_POST["nationality"];
	$ad=$_POST["address"];
    $res=mysql_query("insert into victim_details values('','$u','$n','$fn','$mn','$e','$g','$d','$idc','$cn','$p','$na','$ad')");
	if($res)
		{
	  
			echo 'Victim details saved Successfully';
			//echo "insert into victim_details values('','$u','$n','$fn','$mn','$e','$g','$d','$idc','$cn','$p','$na','$ad')";
			header('refresh:3;url=complaint.php');
			
		}
}
if(isset($_POST['btnsave1']))
{
	$u=$_SESSION['u_id'];
	$an=$_POST["accname"];
	$aad=$_POST["accaddress"];
	$ag=$_POST["accgender"];
	$oi=$_POST["otherinfo"];
	$res1=mysql_query("insert into accused_details values('','$u','$an','$aad','$ag','$oi')");
	if($res1)
	{
		echo 'Accused details saved Successfully';
		header('refresh:3;url=complaint.php');
	}
}

if(isset($_POST['btnsave2']))
{
	$u=$_SESSION['u_id'];
	$noc=$_POST["noc"];
	$doi=$_POST["incdate"];
	$h=$_POST["hour"];
	$m=$_POST["min"];
	$ap=$_POST["ampm"];
	$time=$h.":".$m." ".$ap;
	$st=$_POST["state"];
	$di=$_POST["district"];
	$ps=$_POST["pstation"];
	$pin=$_POST["pincode"];
	$c=$_POST["city"];
	$p=$_POST["phone2"];
	$ides=$_POST["incdes"];
	$tmpimg=$_FILES["imgfile"]["tmp_name"];
	$imgname="img/".$_FILES["imgfile"]["name"];
	if(move_uploaded_file($tmpimg,$imgname))
	{
	$res2=mysql_query("INSERT INTO incident_details VALUES('','$u','$noc','$doi','$time','$st','$di','$ps','$pin','$c','$p','$ides','$imgname')");
	}
	if($res2)
	{
		echo 'Incident details saved Successfully';
		header('refresh:3;url=complaint.php');
	}
}
?>