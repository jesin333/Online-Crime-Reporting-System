<?php
session_start();
if(isset($_SESSION['u_id'])&&isset($_SESSION['fname']))
{
}
else
header('location:login.php');
?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="favicon.png" type="image/png">
	<link rel="shortcut icon" href="favicon.ico" type="img/x-icon">

	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,800italic,700italic,600italic,400italic,300italic,800,700,600' rel='stylesheet' type='text/css'>

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>
	<script type="text/javascript" src="js/wow.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/magnific-popup.js"></script>
	
    <script>
	
	</script>
	<!-- =======================================================
    Theme Name: Knight
    Theme URL: https://bootstrapmade.com/knight-free-bootstrap-theme/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
	======================================================= -->

</head>

<body>
	<!--header-start-->
	<!--header-end-->
<?php include'usermenu.php';?>
	<!--main-nav-end--><!--main-section-end-->
<section class="business-talking">
		<!--business-talking-start-->
		<div class="container">
			<h2>COMPLAINT</h2>
		</div>
</section>
	<!--business-talking-end-->
    
<div class="container"></div>
<div id="exTab1" class="container">	
	<ul  class="nav nav-pills">
		<li class="active"><a  href="#1a" data-toggle="tab">Victim's Details</a></li>
		<li><a href="#2a" data-toggle="tab">Accused Details</a></li>
		<li><a href="#3a" data-toggle="tab">Incident Details</a></li>
	</ul>
	<div class="tab-content clearfix">
		<div class="tab-pane active" id="1a">
        <div class="row">
	    <div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
        <div class="form">
        	<form  method="post" action="complaintreg.php" enctype="multipart/form-data">
            <div class="form-group"><label>Name</label><input class="form-control input-text" type="text" name="name" /></div>
            <div class="form-group"><label>Father's Name</label><input class="form-control input-text" type="text" name="fname"/></div>
            <div class="form-group"><label>Mother's Name</label><input class="form-control input-text" type="text" name="mname"/></div>
            <div class="form-group"><label>Email Id</label><input class="form-control input-text" type="text" name="email"/></div>
            <div class="form-group"><label>Gender</label><select class="form-control input-text" name="gender">
            												<option value="male">Male</option>
                                                            <option value="female">Female</option>
                                                            <option value="other">Other</option>
            											 </select></div>
            <div class="form-group"><label>Date of Birth</label><input class="form-control input-text" type="text" name="dob"/></div>
            <div class="form-group"><label>Phone No</label><input class="form-control input-text" type="text" name="phone1"/></div>
            <div class="form-group"><label>ID Type</label><select class="form-control" name="idtype">
            												<option value="aadhar">Aadhar</option>
                                                            <option value="driving">Driving License</option>
                                                            <option value="pan">PAN Card</option>
            											 </select></div> 
            <div class="form-group"><label>ID Card No</label><input class="form-control input-text" type="text" name="cardno"/></div>
            <div class="form-group"><label>Nationality</label><input class="form-control input-text" type="text" name="nationality" /></div>	
            <div class="form-group"><label>Address</label><textarea class="form-control input-text" name="address" rows="5" cols="25"></textarea></div>	
            <div class="form-group"><button class="btn btn-success"  name="btnsave" type="submit">Save Victim Details</button></div>
		</div>
        </div>
        </div>
        </div>
		<div class="tab-pane" id="2a">
            <div class="row">
	    	<div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
            <form method="post" action="complaintreg.php" enctype="multipart/form-data">
            <div class="form-group"><label>Name</label><input class="form-control input-text" type="text" name="accname"/></div>
            <div class="form-group"><label>Address</label><textarea class="form-control input-text" name="accaddress" rows="5" cols="25"></textarea></div>
            <div class="form-group"><label>Gender</label><select class="form-control input-text" name="accgender">
            												<option value="male">Male</option>
                                                            <option value="female">Female</option>
                                                            <option value="other">Other</option>
            											 </select></div>
           <div class="form-group"><label>Other Information</label><textarea class="form-control input-text" name="otherinfo" rows="5" cols="25"></textarea></div>
           
		   <div class="form-group"><button class="btn btn-success" name="btnsave1" type="submit">Save Accused Details</button></div>
			</div>
            </div>
		</div>
        
        
        <div class="tab-pane" id="3a">
        	<h3>Incident Details</h3>
            <div class="row">
	    	<div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
            <form method="post" action="complaintreg.php" enctype="multipart/form-data">
            <div class="form-group"><label>Nature of complaint</label><input class="form-control input-text" type="text" name="noc"/></div>
            <div class="form-group"><label>Date of incident</label><input class="form-control input-text" type="text" name="incdate"/></div>
			<div class="form-group"><label>Hour</label>
            <select class="form-control" name="hour">
            	<option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select><label>Minutes</label>
            <select class="form-control" name="min">
            	<?php
				$i=1;
				while($i<61)
				{
					echo"<option value='$i'>$i</option>";
					$i++;
				}
				?>
            </select><label>Time Slot</label>
            <select class="form-control" name="ampm">
            	<option value="AM">AM</option>
                <option value="PM">PM</option>
            </select></div>         
             <div class="form-group"><label>Phone No</label><input class="form-control input-text" type="text" name="phone2"/></div>  
            <div class="form-group"><label>State</label><input class="form-control input-text" type="text" name="state"/></div>
            <div class="form-group"><label>District</label><input class="form-control input-text" type="text" name="district"/></div>
	        <div class="form-group"><label>Police station</label><input class="form-control input-text" type="text" name="pstation"/></div>
			<div class="form-group"><label>Pincode</label><input class="form-control input-text" type="text" name="pincode"/></div>
            <div class="form-group"><label>City</label><input class="form-control input-text" type="text" name="city"/></div>
            <div class="form-group"><label>Incident Descriptions</label><textarea class="form-control input-text" name="incdes" rows="5" cols="25"></textarea></div>
            <div class="form-group"><label>Incident Picture</label><input class="form-control input-text" type="file" name="imgfile" id="imgfile"/>
            
		   <div class="form-group"><button class="btn btn-success" name="btnsave2" type="submit">Save Incident Details</button></div>
        </div>
        </form>
       
    </div>
</div>

	<!--main-section alabaster-end--><!--main-section-end--><!--main-section client-part-end--><!--c-logo-part-end-->
	<section class="main-section team" id="team">
	<!--main-section team-start--></section>
	<!--main-section team-end-->



		<footer class="footer">
		<div class="container">
			<div class="footer-logo"><a href="#"><img src="img/footer-logo.png" alt=""></a></div>
			<span class="copyright">&copy; Knight Theme. All Rights Reserved</span>
			<div class="credits">
				<!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Knight
        -->
				Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
			</div>
		</div>
	</footer>


	
</body>

</html>
