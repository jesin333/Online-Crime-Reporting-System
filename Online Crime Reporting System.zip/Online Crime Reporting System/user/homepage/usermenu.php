<?php

if(isset($_SESSION['u_id'])&&isset($_SESSION['fname']))
{
}
else
header('location:login.php');
?>
<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
			<ul class="main-nav">
				<li><a href="userhome.php">Home</a></li>
				<li><a href="complaint.php">Complaints</a></li>
                <li><a href="viewstatus.php">Status</a></li>
				<li class="small-logo"><a href="#header"><img src="img/small-logo.png" alt=""></a></li>
				<li><a href="mycomplaint.php">My Complaints</a></li>
                <li><a href="logout.php">Logout</a></li>
			
			</ul>
            Welcome <?php echo $_SESSION['fname'];?>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"> </i></a>
		</div>
	</nav>
	