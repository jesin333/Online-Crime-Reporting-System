<?php
session_start();
ob_start();
$con=mysql_connect("localhost",'root');
if($con==false)
die("Cannot establish a connection");
$flag=mysql_select_db("crime");
if($flag==false)
die("database is not inserted");

if(isset($_POST['btnlogin']))
{
	$u=$_POST["email"];
	$p=$_POST["password"];
	$res=mysql_query("select * from adminlogin where user='$u' and password='$p'");
	$count=mysql_num_rows($res);
	if($count>0)
	{
	  //echo "Login Successful";
	  header('location:adminprofile.php');
	
	}
	else
	echo "Incorrect username or password";	

}
mysql_close();

?>