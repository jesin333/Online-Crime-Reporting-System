<?php
include "connect.php";
if(isset($_POST['btnsend']))
{
	$id=$_POST['txtuser'];
	$a=$_POST['accusedid'];
	$i=	$u=$_POST['incidentid'];
    $v=$_POST['victimid'];
    $m=$_POST['message'];
	
	$res=mysql_query("insert into status_details values('','$id','$v','$a','$i','$m')");
	if($res)
	{
	//	echo "Message Sent insert into status_details values('','$id','$v','$a','$i','$m')";
	header('refresh:3;url=viewcomplaint.php');
	}



}
?>