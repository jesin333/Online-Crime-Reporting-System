
<nav class="main-nav-outer" id="test">
		<!--main-nav-start-->
		<div class="container">
			<ul class="main-nav">
				<li><a href="adminprofile.php">Home</a></li>
				<li><a href="viewcomplaint.php">View Complaints</a></li>
                <li><a href="userdetails.php">User Details</a></li>
				<li class="small-logo"><a href="#header"><img src="img/small-logo.png" alt=""></a></li>
                <li><a href="logout.php">Logout</a></li>
			
			</ul>
			<a class="res-nav_click" href="#"><i class="fa fa-bars"> </i></a>
		</div>
	</nav>
	