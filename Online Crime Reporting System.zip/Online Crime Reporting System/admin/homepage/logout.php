<?php
session_start();
ob_start();
if(isset($_SESSION['cid']))
unset($_SESSION['cid']);
header("location:index.php");
?>