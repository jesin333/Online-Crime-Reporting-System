<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, maximum-scale=1">

	<title>Homepage</title>
	<link rel="icon" href="favicon.png" type="image/png">
	<link rel="shortcut icon" href="favicon.ico" type="img/x-icon">

	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,800italic,700italic,600italic,400italic,300italic,800,700,600' rel='stylesheet' type='text/css'>

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
	<link href="css/responsive.css" rel="stylesheet" type="text/css">
	<link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.js"></script>
	<script type="text/javascript" src="js/wow.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/magnific-popup.js"></script>
	
    <script>
	
	</script>
	<!-- =======================================================
    Theme Name: Knight
    Theme URL: https://bootstrapmade.com/knight-free-bootstrap-theme/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
	======================================================= -->

</head>

<body>
	
	<!--header-start-->
	<!--header-end-->
<?php include'adminmenu.php';?>
	<!--main-nav-end--><!--main-section-end-->
<section class="business-talking">
		<!--business-talking-start-->
		<div class="container">
			<h2>SEND STATUS</h2>
		</div>
</section>
	<!--business-talking-end-->
    <?php
	if(isset($_GET['vicid'])&&isset($_GET['acid'])&&isset($_GET['inid'])&&isset($_GET['uid']))
	{
		
	
	?>
<div class="row">
			  <div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
				  <div class="form">
                  <form  method="post" action="verifystatus.php">
            <div class="form-group"><label>User ID</label><input class="form-control input-text" type="text" name="txtuser" value="<?php echo $_GET['uid'];?>" readonly /></div>
            <div class="form-group"><label>Victim ID</label><input class="form-control input-text" type="text" name="victimid" value="<?php echo $_GET['vicid'];?>" readonly/></div>
            <div class="form-group"><label>Accused ID</label><input class="form-control input-text" type="text" name="accusedid" value="<?php echo $_GET['acid'];?>" readonly/></div>
            <div class="form-group"><label>Incident ID</label><input class="form-control input-text" type="text" name="incidentid" value="<?php echo $_GET['inid'];?>" readonly/></div>
            <div class="form-group"><label>Message</label><textarea class="form-control input-text" name="message" rows="5" cols="25"></textarea></div>
            <div class="form-group"><input type="submit" class="btn btn-success" name="btnsend" value="Send Message"></div>
            </form>
            <?php
	}
	?>
                  </div>
                  </div>
                  </div>

	<!--main-section alabaster-end--><!--main-section-end--><!--main-section client-part-end--><!--c-logo-part-end-->
	
	<!--main-section team-start-->
	<!--main-section team-end-->



		<footer class="footer">
		<div class="container">
			<div class="footer-logo"><a href="#"><img src="img/footer-logo.png" alt=""></a></div>
			<span class="copyright">&copy; Knight Theme. All Rights Reserved</span>
			<div class="credits">
				<!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Knight
        -->
				Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
			</div>
		</div>
	</footer>


	
</body>

</html>
