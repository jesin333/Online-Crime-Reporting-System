<?php
$con=mysql_connect("localhost",'root');
if($con==false)
die("Cannot establish a connection");
$flag=mysql_select_db("crime");
if($flag==false)
die("database is not inserted");
?>